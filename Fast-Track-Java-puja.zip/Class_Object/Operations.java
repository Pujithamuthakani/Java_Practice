import java.util.*;
class Atm
  {
   long balance;
   void withdraw(long amt)
    {
     if(balance>=amt)
     {
       balance=balance-amt;
       System.out.println("withdraw successfull");
     }
     else
     {
       System.out.println("insufficient balance");
     }
    }
   void deposit(int amt)
    {
      balance=balance+amt;
      System.out.println("deposit successfull");
    }
   void checkbalance()
    {
      System.out.println("balance is: "+balance);
    }
  }
class Operations
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      Atm atm=new Atm();
      atm.balance=10000;
      char ch='y';
      do
      {
       System.out.println("1.Withdraw\n2.Deposit\n3.Checkbalance");
        System.out.println("select option");
        int option=sc.nextInt();
        switch(option)
          {
            case 1:
              System.out.println("enter amount:");
              int amount=sc.nextInt();
              atm.withdraw(amount);
              break;
            case 2:
              System.out.println("enter amount");
              int amount1=sc.nextInt();
              atm.deposit(amount1);
              break;
            case 3:
              atm.checkbalance();
              break;
            default:
              System.out.println("Invalid input");
          }
        System.out.println("Do you want to continue:");
        ch=sc.next().charAt(0);
      }
        while(ch=='y');
    }
  }