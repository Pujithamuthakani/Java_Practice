class Addition
  {
    int a,b,c;
    int add()
    {
     a=5;
     b=6;
     c=a+b;
     return c;
    }
    
  }
class Main 
  {
    public static void main(String args[])
    {
      int z;
      Addition a1=new Addition();
      z=a1.add();
      System.out.println("addtion is: "+z);
    }
  }