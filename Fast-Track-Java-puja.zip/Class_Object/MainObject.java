import java.util.Scanner;
class Studen
  {
    String name;
    int rollno;
    String dept;
    void writing()
    {
      System.out.println("writing");
      }
    void reading()
    {
      System.out.println("reading");
    }
    void studying()
    {
      System.out.println("studying");
    }
    }
class MainObject
  {
    public static void main(String args[])
    {
    Scanner sc=new Scanner(System.in);
   
     
      System.out.println("enter the number of students:");
       int n=sc.nextInt();
       Studen[] st=new Studen[n];
     System.out.println("enter student 1 details: ");
      for(int i=0;i<n;i++)
      {
        st[i]=new Studen();
        System.out.println("enter the name");
        st[i].name=sc.next();
        System.out.println("enter rollno");
        st[i].rollno=sc.nextInt();
        System.out.println("enetr dep");
        st[i].dept=sc.next();
        int j=i+2;
        if(j<=n)
        {
        System.out.println("enter student "+j+" details: ");
          }
      }
}
}