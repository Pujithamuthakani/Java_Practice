class Student
  {
    String name,branch;
    long id;
    public static void main(String args[])
    {
      Student st1=new Student();
      Student st2=new Student();
      Student st3=new Student();
      st1.name="Keerthi";
      st1.id=401;
      st1.branch="ECE";
      st2.name="Mamatha";
      st2.id=402;
      st2.branch="ECE";
      st3.name="Kavya";
      st3.id=403;
      st3.branch="ECE";
      System.out.println("first student name is: "+st1.name+" with id="+st1.id+" , "+st1.branch+" branch.");
      System.out.println("second student name is: "+st2.name+" with id="+st2.id+" , "+st2.branch+" branch.");
      System.out.println("third student name is: "+st3.name+" with id="+st3.id+" , "+st3.branch+" branch.");
    }
    
  }