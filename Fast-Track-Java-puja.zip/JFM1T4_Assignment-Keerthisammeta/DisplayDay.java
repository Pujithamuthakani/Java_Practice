/*
  JFM1T4_Assignment2:
  Write a program to display the name of the day, based on the number, using the switch statement.
  Prompt the user to input a number between 1 and 7. 
  
  Sample Input: 1
  
  Expected Output: Monday
  
*/

//import statements for java program to read inputs using Scanner class 
import java.util.Scanner;

public class DisplayDay {
public static void main(String args[])
  {
//declare number variable
int n;  
//Use the scanner class to provide input at execution time using scanner object
Scanner sc= new Scanner(System.in);
/*
Take input of the number for displaying day
System.out.println("Enter value for displaying day:");
number=sc.nextInt();
*/
    System.out.println("Enter value for displaying day:");
    n=sc.nextInt();
//Declare switch case and check the input value to print the day entered by the user
    switch(n)
    {
      case 1:
        System.out.println("its monday");
          break;
          
        case 2:
        
          System.out.println("its tueseday");
          break;
        
        case 3:
        
          System.out.println("its wednesday");
          break;
        
        case 4:
        
          System.out.println("its thursday");
          break;
        
        case 5:
        
          System.out.println("its friday");
          break;
        
        case 6:
        
          System.out.println("its saturday");
          break;
        
        case 7:
        
          System.out.println("its sunday");
          break;
        
        
    }
   
    }
  
  
}