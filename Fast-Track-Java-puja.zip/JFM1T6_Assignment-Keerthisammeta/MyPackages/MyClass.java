//package
package MyPackages;
//Class MyClass
  public class MyClass
    {
      //method to print the output
    public void display() {
        //printing the welcome message
        System.out.println("Welcome to Packages.");
    }
}
  