class Shape1
  {
    double area(double r)
    { 
    return (3.14*r*r);
    }
    int area(int s)
    {
      return(s*s);
    }
    int area (int l,int b)
    {
      return (l*b);
    }
    double area(double b,double h)
    {
      return(0.5*b*h);
    }
  }
class Shape
  {
    public static void main(String args[])
    {
      Shape1 s=new Shape1();
      double x=s.area(5);
       int z=s.area(7);
      int y=s.area(5,6);
     double m=s.area(5,6);
      System.out.println(m+" "+z+" "+x+" "+y);
    }
  }