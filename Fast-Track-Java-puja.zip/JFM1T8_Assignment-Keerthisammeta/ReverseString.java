/*  JFM1T8_Assignment5:

    Write a program to reverse a string using StringBuffer. Reverse entire sentence in string and also reverse each word in the string. 
    Prompt the user input from the terminal.
    
    Sample input: Learning made easy at bitLabs
    
    Expected output:
    reversing entire string: sbaLtib ta ysae edam gninraeL
    reversing each word at its place: gninraeL edam ysae ta sbaLtib  
*/

import java.util.*;

public class ReverseString {

  public void reverWordInMyString(String s)
   {
/* 
   Use split() method of String class splits
   a string in several strings based on the
   delimiter passed as an argument to it
*/
      String [] st=s.split(" ");
      for(String b:st)
        {
          int n=b.length();
          String rev="";
          for(int i=n-1;i>=0;i--)
            {
/* 
   Use charAt() function returns the character
   at the given position in a string
*/
             rev=rev+b.charAt(i);
            }
          System.out.print(rev+" ");
        }
    }

//main method
  public static void main(String args[])
  {
    //declare variables and take input from user
    Scanner sc =new Scanner(System.in);
    System.out.println("enter a sentance");
    String s=sc.nextLine();
//creat stringbuffer object for string reversing
    StringBuffer obj=new StringBuffer(s);
//reverse input string
    obj.reverse();
//print entire string result
  System.out.println("\n"+"reversing entire string: "+obj);
//call reverWordInMyString method
    ReverseString obj2=new ReverseString();
    System.out.print("\n"+"reversing each word at its place: ");
//print reverse each word string result
    obj2.reverWordInMyString(s); 
    
  }
}