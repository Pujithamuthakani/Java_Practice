/*  JFM1T8_Assignment3:

    Write a program to find a substring in a string without using an inbuilt method of String class.
    Prompt the user input from the terminal.
    
    Sample input: Learning made easy at bitLabs
    Enter search string: bitLabs
    
    Expected output: bitLabs is found
    
    Enter search string: bitlab
    Expected output: bitlab is not found

*/

import java.util.*;
public class SubStringWithoutInbuilt {

   //creat isSubString method in that declare variable
   public boolean isSubString(String s,String str1)
   {
     boolean result = false;
     //using for loop for the first string
     for(int i=0;i<s.length();i++) 
     {
      //using for loop for sub string
      for(int j=0;j<str1.length();j++)
      {
        String [] str=s.split(" ");
          for(String b:str)
            {
             
       //using if condition
       if((str1.length())==(b.length())) 
        {
           int x=str1.compareTo(b);
         //again using if condition
           if(x==0)
           {
             result = true;
           }
          else
           {
            result=false;
           }
        }
      }
    }
     
  }
     return result;
}
       
//main method
  public static void main(String args[])
  {
    //declare variables
    //take input from user
     Scanner sc=new Scanner(System.in);
     System.out.println("enter sentance:");
     String s=sc.nextLine();
     System.out.println("Enter search string : ");
     String str1=sc.next();
//compare two strings if the search string found or not without using inbuilt method isSubString()
   SubStringWithoutInbuilt obj=new SubStringWithoutInbuilt();
//check two strings if the search string is present then return true else return false
    boolean y=obj.isSubString(s,str1);
    if (y==true) 
   {
  //printing weather the sub string is found
  System.out.println("word "+str1+" is found");
  }
   else 
   {
   //printing the sub string is not present in the main string
  System.out.println("Word "+str1+" is not found");
        }
    
    }
}
