/*  JFM1T8_Assignment4:

    Write a program to check whether a string is a Palindrome.
    Prompt the user input from the terminal.
    
    Sample input: Malayalam
    
    Expected output: Malayalam is a Palindrome
*/

import java.util.Scanner;

public class Palindrome 
{

//main method
  public static void main(String args[])
  {
  //declare varible
    String str,rev="";
    //take input from user
    Scanner sc=new Scanner(System.in);
    System.out.println("enter string");
    str=sc.next();
    int l=str.length();
    for(int i=l-1;i>=0;i--)
      {
       rev=rev+str.charAt(i); 
      }
    if(rev.equals(str))
    {
      System.out.println(rev+" is a Palindrome");
    }
    else
    {
      System.out.println(rev+" is not a Palindrome");
    }
/* 
   divide the whole string into two halves and compare each character in the 
   first half with each character in the second half in reverse.  
   If both are equal then it is a palindrome else print it is not a palindrome 
*/
    String str1="",str2="";
    //to get first half of given string
    for(int i=0;i<=(l/2)-1;i++)
     {
      // storing 1st half in str1
     str1=str1+str.charAt(i);
     }
    //to get second half of string
    for(int i=l-1;i>=(l/2);i--)
     {
      // storing 2nd half in str2
     str2=str2+rev.charAt(i);
     }
//comparing 1st half each character with second half each charater in reverse
    if(str1.compareTo(str2)==0)
     {
      System.out.println(str1+" "+str2+" : again a Palindrome");
     }
    else
    {
      System.out.println(str1+" and "+str2+" : not a Palindrome");
    }
      
    

   }
}