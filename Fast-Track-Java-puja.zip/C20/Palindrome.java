import java.util.*;
class Palindrome
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter string:");
      String str=sc.next();
      String rev="";
      int l=str.length();
      for(int i=l-1;i>=0;i--)
        {
          rev=rev+str.charAt(i);
        }
      System.out.println("reverse string is: "+rev);
    }
  }
