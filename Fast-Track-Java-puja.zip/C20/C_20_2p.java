import java.util.*;
  class Perfect
    {
      public int max(int x)
      {
        int sum=0;
        for(int i=1;i<x;i++)
          {
            if(x%i==0)
            {
              sum=sum+i;
            }
          }
        if(sum>x)
            {
              return -1;
            }
            else if(sum<x)
            {
              return 1;
            }
        else
            {
              return 0;
            }
      }
    }
class C_20_2p
  {
    public static void main(String args[])
    {
      int n;
      Scanner sc =new Scanner(System.in);
      System.out.print("Enter number");
      n=sc.nextInt();
      Perfect p = new Perfect();
     int y= p.max(n);
      if(y==-1)
      {
        System.out.println(n+" is an abundant number");
      }
      else if(y==0)
      {
        System.out.println(n+" is an perfect number");
      }
      else
      {
        System.out.println(n+" is an deficient number");
      }
    }
  }
