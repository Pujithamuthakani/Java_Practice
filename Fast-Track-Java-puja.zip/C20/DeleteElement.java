import java.util.*;
class DeleteElement
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int a[]=new int[5];
      System.out.println("enter elements");
      for(int i=0;i<5;i++)
        {
          a[i]=sc.nextInt();
        }
      System.out.println("enter index value:");
      int x=sc.nextInt();
      for(int i=0;i<5;i++)
        {
          if(i==x)
          {
            i++;
          }
           System.out.println(a[i]);
        }
    }
  }