import java.util.*;
class Question3
  {
    public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter size of");
    int n=sc.nextInt();
    
    int a[][]=new int[n][n];
    for(int i=0;i<n;i++)
      {
        for(int j=0;j<n;j++)
          {
            a[i][j]=sc.nextInt();
          }
        }
  for(int i=0;i<n;i++)
      {
        for(int j=0;j<n;j++)
          {
            if(a[i][j]>10 && a[i][j]!=20)
           {
             System.out.println("no");
              return;
            }
            }
        }
       System.out.println("yes");
        }
        }


  