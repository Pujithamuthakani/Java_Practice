import java.util.*;
class NegativeCount
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter array size");
      int n=sc.nextInt();
      int ar[]=new int[n];
      int count=0;
      System.out.println("enter array elements");
      for(int i=0;i<n;i++)
        { 
          ar[i]=sc.nextInt();
          if(ar[i]<0)
          {
            count++;
          }
        }
      System.out.println(count);
    }
  }