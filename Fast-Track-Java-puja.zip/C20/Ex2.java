import java.util.*;

class Ex2
  {
    public static void main(String args[])
    {
     /* int rem,temp;
    Scanner sc=new Scanner(System.in);
   System.out.println("enter size of array");
    int x=sc.nextInt();
    System.out.println("enter your elements");
      int a[]=new int[x];
    for(int i=0;i<x;i++)
        {
          a[i]=sc.nextInt();
          
        }
      for(int i=0;i<x;i++)
        {
          int rev=0;
           temp=a[i];
           while(a[i]!=0)
           {
            
            rem=a[i]%10;//5,0
            rev=(10*rev)+rem ;//5
            a[i]=a[i]/10;//5
             
             }
          
          if(temp==rev)
             {
               System.out.println(rev);
              }
          
         
          }*/
          
     
      
    Scanner sc=new Scanner(System.in);  
    String n=sc.nextLine();
    
      
    
         String [] s=n.split(" ");
          for(String b:s)
            {
             String rev="";
             for(int j=b.length()-1;j>=0;j--)
               {
                 rev=rev+b.charAt(j);
               }
              if(rev.equals(b))
              {
                System.out.println(rev);
              }
              
          }
 
     /* Scanner sc=new Scanner(System.in);
      System.out.println("enter size of array");
      int x=sc.nextInt();
      int count=0;
      System.out.println("enter your elements");
      int a[]=new int[x];
      for(int i=0;i<x;i++)
        {
          a[i]=sc.nextInt();
          
        } 
      System.out.println("enter your element to be deleted");
      int c=sc.nextInt();
      System.out.println("revised array elements are:");
      for(int i=0;i<x;i++)
        {
          if(count==0)
          {
           if(c==a[i])
           {
            i++;
             count++;
            }
          }
          System.out.println(a[i]);
          }*/





      
      }
  }
    
  