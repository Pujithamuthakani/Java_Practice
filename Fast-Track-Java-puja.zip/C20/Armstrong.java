import java.util.*;
class Armstrong
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter number:");
      int n=sc.nextInt();
      int temp=n;
      int sum=0,a;
      while(n!=0)
        {
      a=n%10;//3
      sum=sum+a*a*a;//27
      n=n/10;//14
          }
      if(sum==temp)
      {
        System.out.println("armstrong number: "+temp);
       }
      else
      {
        System.out.println(" not an armstrong number: "+temp);
      }
     }
  }