import java.util.*;
class FirstLast
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter number:");
      int n=sc.nextInt();
      int a=n%10;
      int b=0;
      System.out.println("Last number is :"+a);
     
      while(n!=0)
        {
          b=n%10;//3,4,1
          n=n/10;//14,1,
        }
      System.out.println("first number is:"+b);
    }
  }