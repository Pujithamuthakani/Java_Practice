import java.util.*;
//main class
class Question1
  {
    public static void main(String args[])
    {
      int count1=0,count2=0;
      //input from user
      Scanner sc=new Scanner(System.in);
      System.out.println("enter total number of registrations:");
      int n=sc.nextInt();
      System.out.println("enter registration numbers:");
      int a[]=new int[n];
      for(int i=0;i<=n;i++)
        {
           a[i]=sc.nextInt();
        }
      for(int i=0;i<n;i++)
        {
          if(a[i]%2==0)
          {
            count1++;
          }
        }
             for(int i=0;i<n;i++)
        {
          if(a[i]%2!=0)
          {
            count2++;
          }
        
        }
      System.out.println(count1+" "+count2);
      
      
    }
  }