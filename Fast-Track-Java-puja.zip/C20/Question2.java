import java.util.*;

class NumberType
  {
  
    int findtype(int n)
    {
    
      int sum=0;
      for(int i=1;i<n;i++)
        {
          if(n%i==0)
          {
            sum=sum+i;
          }
        }
      if(sum==n)
          {
           return 0; 
          }
      else if(sum>n)
          {
           return -1;
          }
      else
          {
            return 1;
          }
      }
  }
class Question2
  {
    public static void main(String args[])
    {
      NumberType a=new NumberType();
      Scanner sc=new Scanner(System.in);
      int z=a.findtype(sc.nextInt());
      //System.out.println(z);
      if(z==-1)
      {
        System.out.println("is an abundant number");
      }
      else if(z==0)
      {
        System.out.println("is an perfect number");
      }
      else
      {
        System.out.println("is an deficient number");
      }
    }
  }