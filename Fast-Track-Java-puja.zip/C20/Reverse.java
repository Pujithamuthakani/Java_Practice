import java.util.*;
class Reverse
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter number");
      long n=sc.nextLong();
      long rev=0,sum=0;
      while(n!=0)
        {
        rev= (rev*10) + (n%10);//3,34
         n=n/10;//14,1
        }
      System.out.println(rev);
      
      
    }
  }