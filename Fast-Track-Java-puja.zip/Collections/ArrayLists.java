import java.util.*;
class ArrayLists
  {
    public static void main(String args[])
    {
      Vector<String> a=new Vector<String>();
       a.add("keerthi");
       a.add("vamsi");
       a.add("mamatha");
       a.add("vijay");
       a.add(null);
       a.add("mamatha");
      System.out.println(a);
    }
  }