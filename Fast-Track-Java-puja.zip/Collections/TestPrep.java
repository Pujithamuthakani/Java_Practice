import java.util.*;
/* Write a JAVAprogram to input basiJAVAsalary of an employee and calculate its Gross     salary according to following:
    BasiJAVASalary <= 10000 : HRA = 20%, DA = 80%
    BasiJAVASalary <= 20000 : HRA = 25%, DA = 90%
    BasiJAVASalary > 20000 : HRA = 30%, DA = 95%*/
class TestPrep
  {
    public static void main(String args[])
    {
     float salary,da,hra,GrossPayment;
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter Basic Salary Of Employee: ");
      salary=sc.nextFloat();
      if(salary<=10000 && salary!=0)
      {
        hra=(salary*2)/10;
        da=(salary*8)/10;
      }
      else if(salary<=20000)
      {
        hra=(salary*25)/100;
        da=(salary*9)/10;
      }
      else
      {
       hra=(salary*3)/10;
        da=(salary*95)/100; 
      }
      GrossPayment=salary+hra+da;
      
  System.out.println("Gross Salary Of Employee: "+GrossPayment); 
    }
  }


  
  
