import java.util.*;
class Map_Interface
  {
    public static void main(String args[])
    {
      HashMap<Integer,String> m=new HashMap<Integer,String>();
      m.put(1,"keerthi");
      m.put(2,"vamsi");
      m.put(3,"revathi");
      m.put(4,"mamatha");
      m.put(5,"revathi");
      m.remove(3);
      System.out.println(m);
      for(Map.Entry k:m.entrySet())
      {
        System.out.println(k.getKey()+"  "+k.getValue());
      }
    }
  }