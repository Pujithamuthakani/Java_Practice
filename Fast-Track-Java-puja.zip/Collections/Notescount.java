import java.util.*;
class Notescount
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter  amount");
      int amt=sc.nextInt();
      int a[]={1000,500,100,50,20,10,1};
      int copy=amt;
      int count=0,notes=0;
      
      for(int i=0;i<=6;i++)
        {
          count=amt/a[i];
          if(count!=0)
          {
            System.out.println(a[i]+" x "+count+"="+a[i]*count);
          }
          notes=notes+count;
            amt=amt%a[i];
           }
      System.out.println(notes);
  }
}