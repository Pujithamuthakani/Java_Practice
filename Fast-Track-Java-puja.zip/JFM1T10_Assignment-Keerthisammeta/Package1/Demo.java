package Package1;
public class Demo
  {
    protected String str;
    protected void method()
    {
      System.out.println("Accessed the protected method outside the package using inheritance");
    }
  }