/* JFM1T10_Assignment3:

     Create an abstract class Shape with following data member and methods- 
     Create data members for height and width.
     Add getter and setter methods for height and width.
     Create methods for finding area and perimeter.
     Create three subclasses Square, Rectangle and EquilateralTriangle that extends Shape class and define both the methods.
     Write a program that will find the area and perimeter of 3 Shapes and print the details for all. 
     Prompt the user for the  values to be input from the terminal.
 
     Sample Input:
     Enter Width of Rectangle in meters
     10
     Enter Length of Rectangle in meters
     5
     Enter width of Equilateraltriangle
     15
     Enter radius of circle
     60

     Expected Output:
     Rectangle width: 10.0 meters and length: 5.0 meters
     Resulting area: 50.0 square meters
     Resulting perimeter: 30.0 meters 

     EquiTriangle side: 15.0meters
     Resulting area: 97 square meters
     Resulting perimeter: 45.0 meters 

     Circle radius : 60.0meters
     Resulting area: 11310 square meters
     Resulting perimeter: 377 meters  

*/

import java.util.Scanner;

abstract class Shape{
//declaring variables
     double width,length;
     double radius,side;
     abstract public void area();
     abstract public void perimeter();
}
//adding rectangle class that extends shape class
class Rectangle extends Shape {
     //setter method
     void setValues(double width, double length) {
          this.width = width;
          this.length = length;
     }
     public void area() {
          System.out.println("Resulting area:"+width*length+"square meters");
     }
     public void perimeter() {
          System.out.println("Resulting perimeter:"+2*(width+length)+"Meters");
     }
}
//adding equilateraltriangle class that extends shape class
class EquilateralTriangle extends Shape {
     //setter method
     void setValues(double side) {
          this.side = side;
     }
     public void area() {
          System.out.println("Resulting Area:"+(int)((Math.sqrt(3)/4)*side*side)+"Square meters");
     }
     public void perimeter() {
          System.out.println("Resulting Perimeter:"+3*side+"Meters");
     }
}
//adding circle class that extends shape class
class Circle extends Shape {
     //setter method
     void setValues(double radius){
          this.radius = radius;
     }
     public void area() {
          System.out.println("Resulting Area:"+(int)(radius*radius*Math.PI)+"Square Meters");
     }
     public void perimeter() {
          System.out.println("Resulting Perimeter:"+(int)(2*Math.PI*radius)+"Meters");
     }
}
public class AreaPerimeter {
//main method
     public static void main(String[] args) {
//Scanner class is used to take input from users
          Scanner sc = new Scanner(System.in);
          System.out.println("Enter width of rectangle in meters: ");
          double width = sc.nextDouble(); 
          System.out.println("Enter length of rectangle in meters: ");
          double length = sc.nextDouble();
//declaring rectangle class object
          Rectangle r = new Rectangle();
          r.setValues(width,length);
          System.out.println("Enter width of Equilateral triangle: ");
          double side = sc.nextDouble();
          EquilateralTriangle eq = new EquilateralTriangle();
          eq.setValues(side);
          System.out.println("Enter Radius of circle: ");
          double radius = sc.nextDouble();
          Circle c = new Circle();
          c.setValues(radius);
          System.out.println("");
//printing output of the classes
          System.out.println("Rectanlge Width: "+width+" Meters and length: "+length+" Meters");
          r.area();
          r.perimeter();
          System.out.println("");
          System.out.println("EquiLateral side: "+side+" Meters");
          eq.area();
          eq.perimeter();
          System.out.println("");
          System.out.println("Circle Radius: "+radius+" Meters");
          c.area();
          c.perimeter();
     }
}


