import java.util.*;
class Oneton
  {
    public static void main(String args[])
    {
      int n,i=1;
      System.out.println("enter n value:");
      Scanner sc=new Scanner(System.in);
      n=sc.nextInt();
      while(i<=n)
        {
          System.out.println(i);
          i++;
        }
    }
  }