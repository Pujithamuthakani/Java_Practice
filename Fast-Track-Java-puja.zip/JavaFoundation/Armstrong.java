import java.util.*;
class Armstrong
  {
    public static void main(String args[])
    {
      int n;
      System.out.println("enter a value:");
      Scanner sc=new Scanner(System.in);
      n=sc.nextInt();
      }
  }
      