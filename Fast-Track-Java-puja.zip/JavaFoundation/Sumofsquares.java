class Sumofsquares
  {
    public static void main(String arg[])
    {
    int a=2,b=2,c,d,e;
    c=a*a;
    d=b*b;
    e=c+d;
    System.out.println("sum of squares is:"+ e);
      }
}