class Fivesub
  {
    public static void main(String arg[])
    {
      float a=80,b=60,c=70,d=80,e=90,sum,per;
      sum=a+b+c+d+e;
      System.out.println("obtained marks is:"+sum);
      per=sum*100/500;
      System.out.println("percentage is:"+per);
    }
  }