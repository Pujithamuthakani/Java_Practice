class Simplintr
  {
    public static void main(String args[])
    {
    long p=5000,t=30,r=5,s;
      s=p*t*r/100;
      System.out.println("simple interest is:"+s);
    }
  }