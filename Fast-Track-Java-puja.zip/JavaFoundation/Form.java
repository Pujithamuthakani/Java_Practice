class Form
  {
    public static void main(String[] args)
    {
      int a=2,b=4,c=8,res;
      res=(b*b)-4*a*c;
      System.out.println(res);
    
    }
  }