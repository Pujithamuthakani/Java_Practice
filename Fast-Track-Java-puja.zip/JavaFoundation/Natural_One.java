import java.util.*;
class Natural_One
  {
    public static void main(String args[])
    {
      int n;
     System.out.println("enter n value:");
      Scanner sc=new Scanner(System.in);
      n=sc.nextInt();
      //i=1;
      while(n>=1)
        {
          System.out.println(n);
          n--;
        }
    }
  }