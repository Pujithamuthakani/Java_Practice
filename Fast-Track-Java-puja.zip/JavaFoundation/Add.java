   class Add
  {
    public static void main(String args[])
    {
      int a=10,b=20,sum;
      sum=a+b;
      System.out.println("sum is:"+sum);
    }
  }