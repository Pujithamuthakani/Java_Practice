import java.util.*;
class Prime
  {
    public static void main(String args[])
    {
      int i,n,count=0;
      System.out.println("enter a number:");
      Scanner sc=new Scanner(System.in);
      n=sc.nextInt();
      for(i=1;i<=n;i++)
        {
          if(n%i==0)
          {
            count++;
          }
        }
          if(count==2)
          {
            System.out.println("its a prime number");
          }
          else
          {
            System.out.println("its not a prime number");
          }
      
    }
  }