
import java.util.*;

class Palindrome
{
   public static void main(String[] args)
   {
      int rev=0;
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter a Number: ");
      int n = sc.nextInt();
      int temp = n;
      while(n!=0)
      {
         rev= (rev*10) + (temp%10);
         temp /=10;
      }
      if(temp==rev)
      {
         System.out.println(" is a Palindrome Number.");
        }
      else
      {
         System.out.println(" is not a Palindrome Number.");
        }
   }
}