import java.util.*;
class While_Odd
  {
    public static void main(String args[])
    {
      int i=1,n=100;
      while(i<=n)
        {
          System.out.println(i);
          i=i+2;
        }
    }
  }