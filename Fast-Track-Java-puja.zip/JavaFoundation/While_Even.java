import java.util.*;
class While_Even
  {
    public static void main(String args[])
    {
      int i=2,n=100;
      while(i<=n)
      {
      System.out.println(i);
       i=i+2;
      }
  }
  }