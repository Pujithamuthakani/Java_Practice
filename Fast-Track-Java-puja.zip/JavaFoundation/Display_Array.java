import java.util.*;
class Display_Array
  {
    public static void main(String args[])
    {
      int a[]=new int[5];
      int i;
      System.out.println("enter five array elements:");
      Scanner sc=new Scanner(System.in);
      for(i=0;i<5;i++)
        {
          a[i]=sc.nextInt();
        }
       System.out.println("Five array elements are:");
      for(i=0;i<5;i++)
        {
          System.out.println(a[i]);
        }
    }
  }