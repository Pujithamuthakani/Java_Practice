class Ap
  {
    public static void main(String arg[])
    {
      int b=5,l=10,ar,p;
      ar=l*b;
      p=2*(l+b);
      System.out.println("area of the rectangle is:"+ar+"\nPerimeter is:"+p);
    }
  }