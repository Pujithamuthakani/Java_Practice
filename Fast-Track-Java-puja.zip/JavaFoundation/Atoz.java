import java.util.*;
class Atoz
  {
    public static void main(String args[])
    {
      for(char i='A';i<='Z';i++)
        {
         System.out.println(i); 
        }
      
      for(char i='a';i<='z';i++)
        {
         System.out.println(i); 
        }
    }
  }