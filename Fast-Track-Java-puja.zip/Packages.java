import Grade.Student_Marks;
import Grade.Student_Percentage;
import Grade.Student_Attendance;
class Packages
  {
    public static void main(String args[])
    {
      Student_Attendance n=new Student_Attendance();
      
      n.name=" keerthi";
      n.rollno= 405;
      n.display();
      n.attendace();
      n.totalmarks(90,90,90);
      n.percentage(270);
    }
  }