package Grade;
public class Student_Marks
  {
    public int m1,m2,m3;
    int total_Marks;
    public void totalmarks(int m1,int m2,int m3)
    {
      this.m1=m1;
      this.m2=m2;
      this.m3=m3;
      total_Marks=m1+m2+m3;
      System.out.println("total marks of the student are"+total_Marks);
    }
  }
 
