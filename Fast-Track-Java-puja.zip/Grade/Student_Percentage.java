package Grade;
public class Student_Percentage extends Student_Marks
  {
    public int maxmarks=300;
    
    public void percentage(int total_Marks)
    {
      //super.total_Marks;
      int per=(total_Marks*100)/maxmarks;
      System.out.println("percentage is "+per);
    }
  }