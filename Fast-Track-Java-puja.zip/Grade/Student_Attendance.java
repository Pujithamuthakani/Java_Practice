package Grade;
public class Student_Attendance extends Student_Percentage
  {
    public String name;
    public int rollno;
    public void attendace()
    {
      System.out.println("your attendance is 100%");
    }
    public void display()
    {
      System.out.println("student name is"+name);
      System.out.println("student rollnumber is "+rollno);
    }
  }