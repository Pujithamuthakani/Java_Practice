import java.util.*;
class Array_Prime
  {
    public static void main(String args[])
    {
      int a[]=new int[5];
      int count=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter array elements");
      for(int i=0;i<5;i++)
        {
          a[i]=sc.nextInt();
        }
      
      for(int i=0;i<5;i++)
        {
          for(int j=1;j<=a[i];j++)
            {
              if(a[i]%j!=0)
              {
               count++;
              }
              if(count==2)
              {
               System.out.println(a[i]);
                }
           }
        }
      
    }
  }