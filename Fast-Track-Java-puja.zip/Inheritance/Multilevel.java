import java.util.*;
class Animals
  {
    String color;
    void eat()
    {
      System.out.println("it is eating");
    }
  }
class Dogs extends Animals
  {
    String bread;
    void bark()
    {
     System.out.println("and it is barking");
    }
  }
class Cat extends Dogs
  {
   String gender;
    void meow()
    {
      System.out.println("meow meow");
    }
  }
class Multilevel
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      Cat d=new Cat();
      String c,h;
      System.out.println("enter color of the cat:");
      c=sc.next();
      System.out.println("enter gender of the cat:");
      h=sc.next();
      System.out.println("color of the cat is:"+c);
      System.out.println("gender of the cat is:"+h);
      d.eat();
      d.meow();
    }
  }