import java.util.*;
class Animal
  {
    String color;
    void eat()
    {
      System.out.println("it is eating");
    }
  }
class Dog extends Animal
  {
    String bread;
    void bark()
    {
     System.out.println("and it is barking");
    }
  }
class Single
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      Dog d=new Dog();
      String c,h;
      System.out.println("enter color of the dog:");
      c=sc.next();
      System.out.println("enter breed of the dog:");
      h=sc.next();
      System.out.println("color of the dog is:"+c);
      System.out.println("breed of the dog is:"+h);
      d.eat();
      d.bark();
    }
  }