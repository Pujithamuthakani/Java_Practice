import java.util.*;
class Person
  {
    String name;
    int id;
    void speaking()
    {
      System.out.println("person is speaking");
    }
   
  }
class Student extends Person
  {
    String branch;
    void read()
    {
      System.out.println("reading");
    }
  }
class Graduate extends Student
  {
   void graduate()
    {
      System.out.println("graduating");
    }
  }
class PostGraduate extends Student
  {
    void study()
    {
     System.out.println("studying pg"); 
    }
  }
class Masters extends PostGraduate
  {
    void master()
    {
      System.out.println("masters completed");
    }
  }
class Phd extends PostGraduate
  {
    void research()
    {
     System.out.println("researching"); 
    }
  }
class Employeee extends Person
  {
    void work()
    {
      System.out.println("working");
    }
  }
class Faculty extends Employeee
  {
    String subject;
    
    void teach()
    {
     System.out.println("teaching"); 
    }
  }
class Staff extends Employeee
  {
    void see()
    {
      System.out.println("watching"); 
    }
  }
class Hirarchial
  {
    public static void main(String args[])
    {
     Scanner sc=new Scanner(System.in);
     System.out.println("enter ur name: ");
     String name=sc.next();
     System.out.println("enter ur id: ");
     int id=sc.nextInt();
     System.out.println("enter subject: ");
     String subject=sc.next(); 
     System.out.println("enter branch: "); 
     String branch=sc.next();
     Person p1=new Person();
      System.out.println("name of the student is: "+name+" student rllno is: "+id);
      p1.speaking();
  
      
    }
  }