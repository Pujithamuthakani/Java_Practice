import java.util.*;
class Employee
  {
    private int eid;
    private String ename,edept;
    private long esalary;
    void setEid(int eid)
    {
      this.eid=eid;
    }
    int getEid()
    {
      return this.eid;
    }
    void setEname(String ename)
    {
      this.ename=ename;
    }
    String getEname()
    {
      return this.ename;
    }
    void setEdept(String edept)
    {
      this.edept=edept;
    }
    String getEdept()
    {
      return this.edept;
    }
    void setEsal(long esalary)
    {
      this.esalary=esalary;
    }
    long getEsal()
    {
      return esalary;
    }
  }
class Get_Set2
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      Employee e1=new Employee();
      Employee e2=new Employee();
      System.out.println("enter employe1 id:");
      e1.setEid(sc.nextInt());
      System.out.println("enter employe1 name:");
      e1.setEname(sc.next());
      System.out.println("enter employe1 dept:");
      e1.setEdept(sc.next());
      System.out.println("enter employe1 salary:");
      e1.setEsal(sc.nextLong());
      System.out.println("Employe1 id is:"+e1.getEid()+"\n"+"Employe1 name is:"+e1.getEname()+"\n"+"Employe1 department is:"+e1.getEdept()+"\n"+"Employe1 salary is:"+e1.getEsal());
      System.out.println("\n"+"\n"+"enter employe2 id:");
      e1.setEid(sc.nextInt());
      System.out.println("enter employe2 name:");
      e1.setEname(sc.next());
      System.out.println("enter employe2 dept:");
      e1.setEdept(sc.next());
      System.out.println("enter employe2 salary:");
      e1.setEsal(sc.nextLong());
      System.out.println("Employe2 id is:"+e2.getEid()+"\n"+"Employe2 name is:"+e2.getEname()+"\n"+"Employe2 department is:"+e2.getEdept()+"\n"+"Employe2 salary is:"+e2.getEsal());
    }
  }