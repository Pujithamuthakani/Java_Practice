import java.util.*;
class Student 
  {
    private int rollnum;
    private String name;
    void setRollnum(int rollnum)
    {
      this.rollnum=rollnum;
    }
    int getRollnum()
    {
      return this.rollnum;
    }
    void setName(String name)
    {
      this.name=name;
    }
    String getName()
    {
      return this.name;
    }
  }
class Get_Set
  {
    public static void main(String args[])
    {
      Student st=new Student();
      Scanner sc=new Scanner(System.in);
      System.out.println("enter your roll number:");
      st.setRollnum(sc.nextInt());
      System.out.println("enter your name:");
      st.setName(sc.next());
      System.out.println("name is:"+st.getName()+"\n"+"rollnumber is:"+st.getRollnum());
    }
  }