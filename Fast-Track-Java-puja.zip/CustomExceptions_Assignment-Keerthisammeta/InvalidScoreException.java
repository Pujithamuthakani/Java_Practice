/* 4. Write a program to create custom exception to validate eligibility score to join in bitLabs. 
      Create InvalidScoreException and throw this exception if user entered score is less than 70.

  Sample input:
  Enter your score to check eligibility:  65

  Sample output: 
  Java.lang.InvalidScoreException: "Sorry, you are not eligible to join in bitLabs."


  Sample input:
  Enter your score to check eligibility:  89

  Sample output: 
  "Great, you are eligible to join in bitLabs."
*/

import java.util.*;
//created custom exception to validate eligibility score
class InvalidScoreException1 extends Exception
  {
    InvalidScoreException1(String score)
    {
    super(score);
    }
  }
//main class
public class InvalidScoreException 
{
//main method throws exception
    public static void main(String args[]) throws InvalidScoreException1  
    {
      //scanner class for user input
     Scanner sc=new Scanner (System.in);
      System.out.println("Enter your score to check eligibility:");
      int x=sc.nextInt();
      //try catch used to handle exception
      try{
      if(x>=70)
      {
        System.out.println("Great, you are eligible to join in bitLabs.");
      }
      else
      {
        //throws exception if user enters less than 70
       throw new  InvalidScoreException1("Sorry, you are not eligible to join in bitLabs.");
      }
        }
      catch(Exception e)
        {
          System.out.println(e);
        }
      
    }
}
