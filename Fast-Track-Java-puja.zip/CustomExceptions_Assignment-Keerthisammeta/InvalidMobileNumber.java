/* 3.Write a program to create custom exception to validate mobile number. Create InvalidMobileNumber and throw this exception 
   whenever user enters the mobile number by not following the below conditions.

  ==> mobile number should contain only digits.
  ==> mobile number should contain only 10 digits.
  ==> mobile number should start with 9 or 8 or 7 or 6.

  Sample input: 
  Enter your mobile number: 4565333953
  Sample output: java.lang.InvalidMobileNumber: "Invalid mobile number"

  Sample input: 
  Enter your mobile number: 9884533953
  Sample output: Valid Mobile number
*/
import java.util.*;
//created custom exception to validate mobile number
class InvalidMobileNumberException extends Exception
{
  InvalidMobileNumberException(String mobile)
  {
    super(mobile);
  }
}
//main class
class InvalidMobileNumber
{
  //created method to validate mobile number
  //throws exception when user whenever user enters invalid mobile number
   void checkmobile()throws InvalidMobileNumberException
   {
     //scanner class for user input
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter mobile number");
    String str=sc.next();
     //exception handled using try catch blocks
     try
        {
         long a=Long.parseLong(str);
          }
      catch(Exception e)
        {
           throw new InvalidMobileNumberException("java.lang.InvalidMobileNumber: Invalid mobile number");
          
        }
     //if condition to check munber starts with specified digits or not
    if(str.length()==10 && (str.charAt(0)=='9' || str.charAt(0)=='8' || str.charAt(0)=='7' || str.charAt(0)=='6'))
    {
      System.out.println("Valid Mobile number");
    }
     else
    {
      System.out.println("Enter Valid Mobile number");
    }
    
   }
  //main method
  public static void main(String args[])
  {
    //created object
    InvalidMobileNumber obj=new InvalidMobileNumber();
    //exception handled using try catch
    try
    {
      obj.checkmobile();
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}
