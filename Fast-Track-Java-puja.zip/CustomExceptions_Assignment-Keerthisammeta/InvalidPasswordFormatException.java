/* 1. Write a program to create custom exception to validate password.
      Create InvalidPasswordFormatException and throw this exception
      whenever the user enters the password by not following the below conditions.
      ==> Password should contain at least one digit.
      ==> Password should contain at least one uppercase letter.
      ==> Password should contain at least one lowercase letter.
      ==> Password does not allow space and special characters.

  Sample Input: 
  Enter your password: Password@123
  Sample output: Valid password

  Sample Input: 
  Enter your password: abc123
  Sample output: java.lang.InvalidPasswordFormatException: "Sorry, Invalid passowrd"
*/
import java.util.*;
//created custom exception to validate password.
class InvalidPasswordFormatException1 extends Exception
  {
    InvalidPasswordFormatException1(String password)
    {
    super(password);
    }
  }
//main class
public class InvalidPasswordFormatException 
  {
    //method to check password
    public boolean password(String n) 
    {
      boolean x=false;
      int l=n.length();
      int count1=0,count2=0,count3=0,count4=0;
      //to check all the characters
      for(int i=0;i<=l-1;i++)
        {
          if(n.charAt(i)>='A' && n.charAt(i)<='Z' || n.charAt(i)=='@') 
             {
               count1++;
               }
               if( n.charAt(i)>='a' && n.charAt(i)<='z')
               {
                 count2++;
                 }
                 if(n.charAt(i)>=48 && n.charAt(i)<=57)
                 {
                   count3++;
                   }
          //if password includes below mentioned symbols count4 incriments
              if(( n.charAt(i)>=33 && n.charAt(i)<=47)
                || (n.charAt(i)>=58 &&  n.charAt(i)<=63)
              || ( n.charAt(i)>=91 && n.charAt(i)<=96)
              || (n.charAt(i)>=123 && n.charAt(i)<=126))
              
                    {
                      count4++;
                    }
        }
          
         //gets only true if count1,2,3 are greater than zero and only count 4 is eaquals to zero 
        if(count1>0 && count2>0 && count3>0 && count4==0)
        {
          x=true;
        }
          else
          {
            x=false;
          }
        return x;
  }
   //main method            
  public static void main(String args[])throws InvalidPasswordFormatException1
    {
      //scanner class for user input
     Scanner sc=new Scanner(System.in);
      System.out.println("enter your password");
      String n=sc.next();
      //created object to call methods
      InvalidPasswordFormatException obj=new InvalidPasswordFormatException();
      //exception handled through try catch
      try{
      //valid password only if it only returns true otherwise throws exception
      boolean y=obj.password(n);
        if(y==true)
        {
         System.out.println("Valid password"); 
        }
        else
          {
            throw new InvalidPasswordFormatException1("Sorry, Invalid passowrd");
          }
        
        }
      catch(Exception e)
        {
          System.out.println(e);
        }
    }
}
