/* 5. Write a program create custom Exception to manage stock. Create OutOfStockException and throw this exception if user 
     entered stock is not present while purchase products. Create the following methods.
     ==> addStock(int qty)   : write code to add stock
     ==> purchase(int qty)   : write code to purchase products
     ==> diplayStock()       : write code to display available stock

  Display list of options to user before accept option from user, such as 
  1. addStock  
  2. purchaseProduct 
  3. displayStock
*/
import java.util.*;
//create custom Exception to manage stock
class OutOfStockException1 extends Exception
  {
    OutOfStockException1(String stock)
    {
      super(stock);
    }
  }
//main class
public class OutOfStockException 
  {
    //arraylist to maintain stock
    
    ArrayList<Integer> Stock=new ArrayList<Integer>();

   //method to add stock 
    public void addStock(int qyt)
    {
     Stock.add(qyt);
     Stock.add(2);
     Stock.add(3);
     Stock.add(7);
     Stock.add(5);
     Stock.add(6);
     Stock.add(8);
     System.out.println("Added to stock successful"); 
    }
    //method to purchaseproduct
    //throws exception if user tries to purchase product outofstock
     public void purchaseProduct(int qyt) throws OutOfStockException1
    {
      if(Stock.contains(qyt))
      {
       Stock.remove(qyt);
      }
      else
      {
      throw new OutOfStockException1("Purchase failed due to OutOfStock");
      }
      }
    //method to display available stock
    public void displayStock()
    {
      System.out.println(Stock);
    }
    
//main method
    public static void main(String args[]) 
  {
    //scanner class for user input
    Scanner sc=new Scanner(System.in);
    //created object to call methods
    OutOfStockException obj=new OutOfStockException();
    char ch='S';
    do
      {
        //display user to take chocice
     System.out.println("enter your choice"+"\n"+"1. addStock"+"\n"+"2. purchaseProduct"+"\n"+ "3. displayStock ");
    int n=sc.nextInt();
    //starting of switch case
    switch(n)
      {
        case 1:
           System.out.println("enter quantity to add to stock");
            int x=sc.nextInt();
            obj.addStock(x);
            break;
        case 2:
           System.out.println("enter quantity to purchase from stock");
            int y=sc.nextInt();
          //exception handled using try catch
          try{
            obj.purchaseProduct(y);
            }
          catch(Exception e)
            {
             System.out.println(e); 
            }
            break;
        case 3:
            obj.displayStock();
            break;
        default:
          System.out.println("enter valid choice");
      }
        //if the user wants to continue
          System.out.println("\n"+"Do you want to continue:");
          ch=sc.next().charAt(0);
        }
           while(ch=='S');
        
    }
}
