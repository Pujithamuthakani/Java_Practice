/* 2. Write a program to create custom exception to perform deposit and withdraw options. 
      Create InvalidAmountException and throw this exception whenever user trying to deposit or withdraw invalid amount. 
      Deposit and withdraw amount should be multiples of 100 and it should be positive value.
*/

import java.util.Scanner;
//custom exception class InvalidAmount
class InvalidAmount extends Exception
{
  InvalidAmount(String amount)  
  {
    super(amount);
  }
}
//main class
class CustomException 
{
  int amt,bal=10000;
//created deposit method 
//throws InvalidAmountexception when user tries to deposit amount not 100 multiples and less than zero
  public void deposit(int amt) throws InvalidAmount
     { 
       if(amt%100==0 && amt>0)
       {
        bal=bal+amt;
        System.out.println(bal); 
       }
       else
       {
         throw new InvalidAmount("invalid amount");
       }
       
     }
  //created withdraw method
  //throws InvalidAmountexception when user tries to withdraw amount not 100 multiples and great than balance
  public void withdraw(int amt) throws InvalidAmount
    {
       if(amt%100==0 && amt>bal)
       {
        bal=bal-amt;
         System.out.println(bal);
       }
       else
       {
         throw new InvalidAmount("invalid amount");
       }
    }
  //created main method
public static void main(String args[]) 
    {
      //scanner class for user input
      Scanner sc=new Scanner(System.in);
      System.out.println("enter amount to withdraw");
      int amt=sc.nextInt();
      System.out.println("enter amount to deposit");
      int amt1=sc.nextInt();
      //created object for calling methods
      CustomException d=new CustomException();
      //exception handled using try catch block
      try{
      d.withdraw(amt);
      d.deposit(amt1);
        }
      catch(Exception e)
        {
          System.out.println(e);
        }
    }
}
