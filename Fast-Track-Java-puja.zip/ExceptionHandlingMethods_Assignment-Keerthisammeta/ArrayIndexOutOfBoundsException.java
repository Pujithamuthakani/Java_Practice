/* 5. Write a program to find prime numbers from given two arrays and store in 3rd array. 
      Handle ArrayIndexOutOfBoundsException while storing values into 3rd array.
*/
//to insert the prime numbers of two strings into the third string

    
import java.util.*;
 class ArrayIndexOutOfBoundsException
  {
    public static void main(String args [])
    {
      int n,m,count=0,count1=0;
      Scanner sc = new Scanner(System.in);
      //size of the first array
      System.out.println("enter the size of the first array:");
      n=sc.nextInt();
      int a[] = new int[n];
      //size of second array
       System.out.println("enter the size of the second array:");
       m=sc.nextInt();
      int b[] = new int[m];
      //enterint the elements into the first array
      System.out.println("enter elements of first array:");
      for(int i=0;i<n;i++)
        {
          a[i] = sc.nextInt();
        }
      //entering the elements into second string
       System.out.println("enter elements of second array:");
      for(int i=0;i<m;i++)
        {
          b[i]= sc.nextInt();
        }
    System.out.println("list of prime numbers stored in 3rd array are:");
      for(int i=0;i<n;i++)
        {
          for(int j=1;j<=a[i];j++)
            {
              if(a[i]%j==0)
              {
               count++;
             
              }
            }
         
          if(count==2 )
          {
            
            System.out.println(a[i]);
          }
          count=0;
         
        }
      
      for (int i=0;i<m;i++)
        {
          for(int k=1;k<=b[i];k++)
            {
              if(b[i]%k==0)
              {
               count1++;
              }
            }
          
           if(count1==2 )
           {
              
             
             System.out.println(b[i]);
             
             count1=0;
           }
         
               
        }
      
     
    }
  }