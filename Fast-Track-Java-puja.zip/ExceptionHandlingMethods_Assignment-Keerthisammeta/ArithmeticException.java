/* 1.Write a program to accept two numbers, one Arithmetic operator such as +, -, / , *  and print output of Arithmetic operation. 
   Write switch case to perform each operation. Handle ArithmeticException when you are performing division operation. 
*/

//importing scanner class
import java.util.*;
//main class
class ArithmeticException 
  {
//main method
    public static void main(String args[])
    {
// reading input
      Scanner sc=new Scanner(System.in);
      System.out.println("enter your choice:"+"\n"+"+.addition"+"\n"+"-.subtraction"+"\n"+"/.division"+"\n"+"*.multiplication");
      char n=sc.next().charAt(0);
      System.out.println("enter two values for subtraction:");
      int a=sc.nextInt();
      int b=sc.nextInt();
//switching operation using swith case
      switch(n)
        {
          case '+':
             System.out.println("the addition of given numbers is:"+(a+b));
            break;
          case '-':
            System.out.println("subtractin of given numbers is"+(b-a));
            break;
          case '/':
            try
              {
             System.out.println("division of given numbers is"+a/b);
              }
            catch(Exception e)
              {
                System.out.println(e);
              }
            break;
          case '*':
            System.out.println("multiplication of given numbers is"+a*b); 
            break;
          default:
            {
              System.out.println("enter a valid choice");
            }
        }
    }
  }
  
