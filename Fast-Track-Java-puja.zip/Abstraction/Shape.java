abstract class Shape1
  {
    abstract void draw();
  }
class Rectangle extends Shape1
  {
    void draw()
    {
      System.out.println("its a rectangle");
    }
  }
class Square extends Shape1
  {
    void draw()
    {
      System.out.println("its a square");
    }
  }
class Circle extends Shape1
  {
    void draw()
    {
      System.out.println("its a circle");
    }
  }
class Shape
  {
    public static void main(String args[])
    {
      Shape1 r=new Rectangle();
      Shape1 s=new Square();
      Shape1 c=new Circle();
      r.draw();
      s.draw();
      c.draw();
      
    }
  }