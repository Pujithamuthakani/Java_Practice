import java.util.*;
class Exception3
  {
    public static void main(String args[])
    {
      String a=null;
      System.out.println(a.length());
    }
  }