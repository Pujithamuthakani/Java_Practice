import java.util.*;
class Interview
  {
    public static void main(String args[])
    {
      int res=1,res1=0,res2;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter number");
      int n=sc.nextInt();
      System.out.print("0 1 ");
      for(int i=1;i<=n;i++)//1,2
        {
           res2=res1+res;//123
           res1=res;//11
           res=res2;//12
          System.out.print(res2+" ");
        }
      
    }
   
  }
//0,1,res,1,2,3,5,8,13,21,34...user 8