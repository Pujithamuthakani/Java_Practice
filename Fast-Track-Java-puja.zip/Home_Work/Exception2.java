import java.util.*;
class Exception2
  {
    public static void main(String args[])
    {
     int i;
      int a[]=new int[5];
      Scanner sc=new Scanner(System.in);
      System.out.println("enter elements:");
      for(i=0;i<5;i++)
        {
          a[i]=sc.nextInt();
        }
      System.out.println(a[6]);
    }
  }