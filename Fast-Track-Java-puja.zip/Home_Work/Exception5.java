import java.util.*;
class Exception5
  {
    public static void main(String args[])
    {
     Scanner sc=new Scanner(System.in);
      System.out.println("enter a value:");
      int a=sc.nextInt();
      System.out.println("enter b value:");
       int b=sc.nextInt();
      System.out.println(a/b);
    }
  }