import java.util.Scanner;
  class Invalidmobilenumber extends Exception
  {
    //coustom exception for invalid mobile number
    Invalidmobilenumber(String mobilenumber){
    super(mobilenumber);
    }
      //so as to access the mobile number super key word is used
   }
 

  //main class
class Number_exception
  {
    //main medthod
    void num()
    throws Invalidmobilenumber
    {
      //throws  indicates the exception
      //array if mobile number is created
      int mobilenumber[]= new int[10];
      //scanner class to read the mobile number from the user
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter array of moblie number");
      // for loop to read all the elements
      for(int i=0;i<10;i++)
        {
          //input for mobile number
          //i indicates the index number
          mobilenumber[i] =sc.nextInt();
        }
          if(mobilenumber[0]>6 && mobilenumber[0]<10)
            //mobilenumber[0]  gives the first number of the mobile number.
            //as we had a condition that it should start with 9,8,7,6
          {
            //throw throws the invalid mobile number exception
            System.out.println("entered mobile number is valid");
          }
          else
          {
            throw new Invalidmobilenumber("invalid");
            
          }
          System.out.println("The molibe is :");
             for(int i=0;i<10;i++)
            {
              System.out.print(mobilenumber[i]);
            }
      }
          public static void main(String args[])
          {
            Number_exception obj=new Number_exception();
         //for printing the mobile number that user has given
            try
             {
                obj.num();
             }
           catch(Exception e)
            {
             System.out.println(e);
            }
             
           }
      
  }








  
    
