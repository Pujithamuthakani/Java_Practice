import java.util.*;
class Ref_Cont
  {
    public static void main(String args[])
    {
      /*String str1=" bitlabs";
      String str2="bitlabs";
      String str3=new String();
      String str4=new String();
      String str5="vamsi, keerthi, vijay";*/
      /*if(str1==str2)
      {
        System.out.println("same reference");
      }
      else
      {
       System.out.println("different reference"); 
      }
      if(str1.equals(str2))
      {
        System.out.println("same content");
      }
      else
      {
       System.out.println("different content"); 
      }
      if(str3==str4)
      {
        System.out.println("same reference"); 
      }
      System.out.println(str1);
      System.out.println(str1.trim());*/
      /*if(str5.contains("keerthi"))
      {
        System.out.println("word present");
      }
      else{
        System.out.println("not present");
      }*/
      String str1,str2;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a sentence");
      str1=sc.nextLine();
      System.out.println("enter a word to check");
      str2=sc.nextLine();
      if(str1.contains(str2))
      {
        System.out.println(str2+" is present");
      }
      else
      {
        System.out.println(str2+" is not present");
      }
      
      
      
    }
  }