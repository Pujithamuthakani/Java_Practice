import java.util.*;
class Exception4
  {
    public static void main(String args[])
    {
      String a="hai";
      int x=Integer.parseInt(a);
      System.out.println(x);
    }
  }