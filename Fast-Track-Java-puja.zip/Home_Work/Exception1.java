import java.util.Scanner;
class InvalidMobileNumber extends Exception
{
  InvalidMobileNumber(String mobile)
  {
    super(mobile);
  }
}
class Exception1
{
   void checkmobile() throws InvalidMobileNumber
   {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter mobile number");
    String str=sc.next();
   
    if(str.length()==10 && (str.charAt(0)=='9' || str.charAt(0)=='8' || str.charAt(0)=='7' || str.charAt(0)=='6'))
    {
      System.out.println("valid mobile number");
    }
    else
    {
      throw new InvalidMobileNumber("Invalid");
    }
   }
  public static void main(String args[])
  {
    Exception1 obj=new Exception1();
    try
    {
      obj.checkmobile();
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}
