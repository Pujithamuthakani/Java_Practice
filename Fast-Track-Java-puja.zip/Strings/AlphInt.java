import java.util.*;
class AlphInt
  {
    public static void main(String args[])
    { 
      String str;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter sentence");
      str=sc.nextLine();
      int l=str.length();
      int count1=0,count2=0,count3=0;
      for(int i=l-1;i>=0;i--)
        {
          if(str.charAt(i)>='a' && str.charAt(i)<='z')
          {
            char ch=charAt(i);
            count1++;
          }
         else if(str.charAt(i)>='0' && str.charAt(i)<='9')
          {
            count2++; 
          }
          else
          {
            count3++; 
          }
        }
          
    System.out.println("number of integers are: "+count1+" "+count2+" "+count3);
          
          
      }
  }