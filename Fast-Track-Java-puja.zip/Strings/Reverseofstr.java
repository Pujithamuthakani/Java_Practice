
import java.util.*;
class Reverseofstr
  {
    public static void main(String args[])
    {
      String rev1="";
      String rev2="";
     /* char [] ch=str.toCharArray();
      for(Character c:ch)
        {
          System.out.print(c+" ");
        }
      String [] str1=str.split(" ");
      for(String b:str1)
        {
         System.out.println("\n"+"\n"+b); 
        }
      */
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a sentence1");
      String str1=sc.nextLine();
      System.out.println("enter a sentence2");
      String str2=sc.nextLine();
      int l=str1.length();
      int m=str2.length();
      for(int i=l-1;i>=0;i--)
        {
          rev1=rev1+str1.charAt(i);
        }
      System.out.println(rev1);
      for(int i=m-1;i>=0;i--)
        {
          rev2=rev2+str2.charAt(i);
        }
      System.out.println(rev2);
       
      if(str1.equals(rev1))
      {
        System.out.println(rev1+": is a palindrome string");
      }
      else
      {
        System.out.println(rev1+": is not a palindrome string");
      }
       if(str2.equals(rev2))
      {
        System.out.println(rev2+": is a palindrome string");
      }
      else
      {
        System.out.println(rev2+": is not a palindrome string");
      }
      System.out.println(str1+str2);
    }
  }